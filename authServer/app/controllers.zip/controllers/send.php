<?php
function send2rabbitmq($address, $routeKey, $message)
{
	$exchangeName = '';

	$connection = new AMQPConnection(array('host' => $address, 'port' => '5672', 'login' => 'guest', 'password' => 'guest'));

	var_dump("is connecting...");

	$connection->connect() or die("Cannot connect to the broker!\n");	 

	var_dump("connecting");

	try {
		$channel = new AMQPChannel($connection);
		$exchange = new AMQPExchange($channel);
		$exchange->setName($exchangeName);

		$exchange->publish($message,$routeKey);

			var_dump("[x] Sent 'Hello Sun!'");

	} catch (AMQPConnectionException $e) {

			var_dump($e);

				exit();
	}

	$connection->disconnect();
}

?>
