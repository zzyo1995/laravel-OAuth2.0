<?php
include 'send.php';
class ProjectGroupController extends \BaseController {

	public function __construct()
    {
        $this->beforeFilter('user.manage');
    }

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index(){

        $userId = Auth::user()->id;
        $companyUsers = CompanyUser::getCompanyUserByUserId($userId);

        foreach($companyUsers as $eachCompanyUser){
            $company = Company::find($eachCompanyUser->company_id);
            $companies[] = $company;
        }

        if(!isset($companies)) {
            $companies[] = null;
        }

        return View::make('department.index', array('nav_active' => 'projectGroup', 'companies' => $companies));

    }


	public function showGroups()
	{
		//
		$companyId = Input::get('companyId');
		$companyName = Input::get('companyName');

		$projectGroups = ProjectGroup::listGroups($companyId, null);
		return View::make('projects.index',array('projectGroups' => $projectGroups, 'companyId' => $companyId, 'companyName' => $companyName, 'nav_active' => 'projectGroup'));
	}

	public function getAddProjectGroup(){
		$companyId = Input::get('companyId');
		$companyName = Input::get('companyName');
		//print $departmentId;
		return View::make('projects.create', array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'companyName' => $companyName));
	}

	public function postAddProjectGroup(){
		$companyId = Input::get('companyId');
		$companyName = Input::get('companyName');
		$projectGroupName =Input::get('name');
		$projectGroupInfo = array(
			'company_id' => $companyId,
			'name'			=> $projectGroupName,
		);

		$existGroup = ProjectGroup::queryByCondition($companyId, null, $projectGroupName);

		if($existGroup != null){
			return Redirect::action("ProjectGroupController@getAddProjectGroup", array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'companyName' => $companyName))
				->with('error', "项目组 '".$projectGroupName."' 已存在!");
		}

		$projectGroup = new ProjectGroup($projectGroupInfo);
		if($projectGroup->save(ProjectGroup::$rules)){

			$user = User::find(Auth::user()->id);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$companyId;
			$message = '{type:1_0, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroup->id.'", "company_id":"'.$companyId.'", "message":"add a new project group"}';

			RabbitMQ::publish($exchange, $routeKey, $message);
			send2rabbitmq('localhost', 'secfile', '{"action":"CreateProjectGroup","email":"'.$user->email.'","project_group_id":'.$projectGroup->id.',"company_id":'.$companyId.',"company_name":"'.$companyName.'","project_group_name":"'.$projectGroupName.'"}');
			return Redirect::action('ProjectGroupController@showGroups', array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'companyName' => $companyName))
				->with('success', '创建项目组成功！');
		}


	}

	/**
	 * 子项目组列表
	 * @return
	 */
	public function sonGroups(){
		$companyId = Input::get('companyId');
		$superId = Input::get('superId');

		$projectGroups = ProjectGroup::listGroups($companyId, $superId);
		return View::make('projects.sonIndex',array('projectGroups' => $projectGroups, 'companyId' => $companyId, 'superId' => $superId, 'nav_active' => 'projectGroup'));
	}

	/**
	 * 跳转到添加子项目组页面
	 * @return mixed
	 */
	public function getAddSonProjectGroup(){
		$companyId = Input::get('companyId');
		$superId = Input::get('superId');
		//print $departmentId;
		return View::make('projects.createSon', array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'superId' => $superId));
	}


	public function postAddSonProjectGroup(){
		$companyId = Input::get('companyId');
		$superId = Input::get('superId');
		$projectGroupName =Input::get('name');
		$projectGroupInfo = array(
			'company_id' => $companyId,
			'name'	=> $projectGroupName,
			'super_id' => $superId
		);

		$existGroup = ProjectGroup::queryByCondition($companyId, $superId, $projectGroupName);

		if($existGroup != null){
			return Redirect::action("ProjectGroupController@getAddSonProjectGroup", array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'superId' => $superId))
				->with('error', "项目组 '".$projectGroupName."' 已存在!");
		}

		$projectGroup = new ProjectGroup($projectGroupInfo);
		if($projectGroup->save(ProjectGroup::$rules)){

			$user = User::find(Auth::user()->id);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$companyId;
			$message = '{"type":1_0, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroup->id.'", "company_id":"'.$companyId.'", "message":"add a son project group"}';

			RabbitMQ::publish($exchange, $routeKey, $message);

			return Redirect::action('ProjectGroupController@sonGroups', array('nav_active' => 'projectGroup', 'companyId' => $companyId, 'superId' => $superId))
				->with('success', '创建项目组成功！');
		}

	}

	public function projectMember(){
		$projectGroupId = Input::get('projectGroup_id');
		$projectGroupName = Input::get('projectGroup_name');

		//print_r($projectGroupId);
		$allMember = ProjectGroupMember::listMembers($projectGroupId);
		foreach($allMember as $member){
			$user = User::find($member->user_id);
			$userInfo[] = array(
				'id' => $user->id,
				'username' => $user->username,
				'email' => $user->email,
				'phone' => $user->phone,
				'type'	=> $member->type,
			);
		}
		if(!isset($userInfo)){
			$userInfo[] = array();
		}

		//print_r($userInfo[0]['username']);
		//print_r($userInfo);

		return View::make('projects.allMember', array('nav_active' => 'projectGroup', 'userInfo' => $userInfo, 'projectGroupName' => $projectGroupName, 'projectGroupId' => $projectGroupId));

	}

	public function setLeader(){
		$userId = Input::get('userId');
		$projectGroupId = Input::get('projectGroup_id');
		$projectGroupName = Input::get('projectGroup_name');

		if(ProjectGroupMember::updateType($projectGroupId, $userId, 1)){

			$user = User::find($userId);
			$projectGroup = ProjectGroup::find($projectGroupId);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$projectGroup->company_id;
			$message = '{"type":2_2, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroupId.'", "company_id":"'.$projectGroup->company_id.'", "message":"the member set to be a leader"}';

			RabbitMQ::publish($exchange, $routeKey, $message);

		}

		return Redirect::action('ProjectGroupController@projectMember', array('projectGroup_id' => $projectGroupId, 'projectGroup_name' => $projectGroupName));

	}

	public function cancelLeader(){
		$userId = Input::get('userId');
		$projectGroupId = Input::get('projectGroup_id');
		$projectGroupName = Input::get('projectGroup_name');

		if(ProjectGroupMember::updateType($projectGroupId, $userId, 0)){

			$user = User::find($userId);
			$projectGroup = ProjectGroup::find($projectGroupId);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$projectGroup->company_id;
			$message = '{"type":2_2, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroupId.'", "company_id":"'.$projectGroup->company_id.'", "message":"the member cancel the leader"}';

			RabbitMQ::publish($exchange, $routeKey, $message);

		}

		return Redirect::action('ProjectGroupController@projectMember', array('projectGroup_id' => $projectGroupId, 'projectGroup_name' => $projectGroupName));
	}

	public function getAddProjectMember(){
		$projectGroupId = Input::get('projectGroup_id');

		$projectGroup = ProjectGroup::find($projectGroupId);

		$company = $projectGroup->company;

		$companyUsers = $company->companyUser;

		foreach($companyUsers as $companyUser){
			if($companyUser->state == 1){
				$member = ProjectGroupMember::queryByUid($projectGroupId, $companyUser->user_id);
				if($member == null){
					$users[] = User::find($companyUser->user_id);
				}
			}
		}

		if(!isset($users)){
			$users[] = array();
		}

		//var_dump($companyUsers);
		return View::make('projects.addMember', array('nav_active' => 'projectGroup', 'allUser' => $users, 'projectGroup_id' => $projectGroupId, 'projectGroupName' => $projectGroup->name));

	}

	public function postAddProjectMember(){
		$projectGroupId = Input::get("project_group_id");
		$projectGroupName = Input::get("project_group_name");
		$uidStr = Input::get("uid");

		if($uidStr != ""){
			$arr = explode(",",$uidStr);
			foreach($arr as $uid){
				$member = ProjectGroupMember::queryByUid($projectGroupId, $uid);
				if($member == null) {
					$memberInfo = array(
						"project_group_id" => $projectGroupId,
						"user_id" => $uid
					);
					$projectGroupMember = new ProjectGroupMember($memberInfo);

					if($projectGroupMember->save(ProjectGroupMember::$rules)){

						$user = User::find($uid);
						$projectGroup = ProjectGroup::find($projectGroupId);

						//组织关系修改, 发送消息到队列
						$exchange = 'org';
						$routeKey = 'org.change.'.$projectGroup->company_id;
						$message = '{"type":2_0, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroupId.'", "company_id":"'.$projectGroup->company_id.'", "message":"the project group has added new member"}';
						$companyapply = DB::table('company')->where('id',$projectGroup->company_id)->first();
						send2rabbitmq('localhost', 'secfile', '{"action":"DestributeMember","company_id":'.$projectGroup->company_id.',"project_group_id":'.$projectGroupId.',"company_name":"'.$companyapply->name.'","project_group_name":"'.$projectGroupName.'","employee_email":"'.$user->email.'"}');
						RabbitMQ::publish($exchange, $routeKey, $message);

					}
				}
			}
		}

		return Redirect::action("ProjectGroupController@projectMember", array("projectGroup_id" => $projectGroupId, "projectGroup_name" => $projectGroupName));

	}

	public function deleteProjectMember(){
		$projectGroupId = Input::get("projectGroup_id");
		$userId = Input::get("userId");

		$member = ProjectGroupMember::queryByUid($projectGroupId, $userId);

		if(ProjectGroupMember::deleteMemberById($member->id)) {
			$projectGroup = ProjectGroup::find($projectGroupId);

			$user = User::find($userId);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$projectGroup->company_id;
			$message = '{"type":2_1, "email":"'.strtolower($user->email).'", "group_id":"'.$projectGroupId.'", "company_id":"'.$projectGroup->company_id.'", "message":"the project group has added new member"}';

			RabbitMQ::publish($exchange, $routeKey, $message);
			$companyapply = DB::table('company')->where('id',$projectGroup->company_id)->first();
			send2rabbitmq('localhost', 'secfile', '{"action":"DeleteMember","email":"'.$user->email.'","company_name":"'.$companyapply->name.'","project_group_name":"'.$projectGroup->name.'","company_id":'.$projectGroup->company_id.',"project_group_id":'.$projectGroupId.'}');

			return Redirect::action("ProjectGroupController@projectMember", array("projectGroup_id" => $projectGroupId, "projectGroup_name" => $projectGroup->name))
				->with("success", "删除成功");
		}
		$projectGroup = ProjectGroup::find($projectGroupId);
		return Redirect::action("ProjectGroupController@projectMember", array("projectGroup_id" => $projectGroupId, "projectGroup_name" => $projectGroup->name))
			->with("error", "删除失败");

	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
		$projectId = $id;
		$companyId = Input::get('companyId');

		$groupState = ProjectGroup::deleteGroupById($projectId);
		ProjectGroupMember::deleteMember($projectId);

		if($groupState){

			$user = User::find(Auth::user()->id);

			//组织关系修改, 发送消息到队列
			$exchange = 'org';
			$routeKey = 'org.change.'.$companyId;
			$message = '{"type":1_1, "email":"'.strtolower($user->email).'", "group_id":"'.$projectId.'", "company_id":"'.$companyId.'", "message":"the project group has been deleted"}';

			RabbitMQ::publish($exchange, $routeKey, $message);

			return Redirect::action('ProjectGroupController@showGroups', array('nav_active' => 'projectGroup', 'companyId' => $companyId))
				->with('success', "删除成功!");
		}

		return Redirect::action('ProjectGroupController@showGroups', array('nav_active' => 'projectGroup', 'companyId' => $companyId))
				->with('error', "删除失败!");

	}


}
