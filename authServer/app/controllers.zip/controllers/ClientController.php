<?php

class ClientController extends BaseController {

    public function __construct()
    {
        $this->beforeFilter('user.admin', array('only' => 'index'));
    }

    public function index()
    {
        $allClients = Client::all();//提取所有的客户端信息
        return View::make('clients.index', array('nav_active' => 'clients', 'clients' => $allClients));//转向客户端列表
    }

	public function create()//客户端注册
	{
        	$scopes = Scope::all();
        	$scopenames = [];
        	foreach ($scopes as $scope) {
            		$scopenames[] = $scope['name'];
        	}

        	return View::make('clients.create', ['scope_options' => $scopenames]);
	}

	public function store()
	{
		$client_type = Input::only('client_type') ;
		$redirect_url = Input::only('redirect_url') ;
		$client_info = Input::except('client_type','redirect_url');
		
		$rules = array(
			"id"=>'required',
			'name'=>'required',
			'scope'=>'required'
		) ;
		
		$validator = Validator::make($client_info,$rules) ;
		if($validator->fails())
		{	//如果验证未通过，则重新加载客户端注册页面
			return Redirect::route('clients.create')
			            ->withInput()
			            ->withErrors($validator->errors());		
		}
		
		$client_info['secret'] = str_random(16);
        	$si = $client_info['scope'];
        	unset($client_info['scope']);
        
        	$c = new Client($client_info);//调用/models的Client类
        	$id = $c->id;//取得客户端ID

       		 if($c->save()) {
            		$c = Client::find($id); // 需要重新获取对象，否则对象id为0
           			$scopes = Scope::all();
            		foreach ($si as $sindex) {
                		$c->scopes()->attach($scopes[$sindex]->id);
            		}
            
           		 if($client_type['client_type'] == "client")
           		 {	//客户端类型：客户端
            			return Redirect::route('home')
            			->with('success', '客户端已注册。请记住客户端认证码（client_secret）：'.$c->secret);
         		   }
           		 else
           		 {
				//客户端类型：web
	          		  $clientEndpoint = new ClientEndpoint(array('client_id'=>$id,'redirect_uri'=>$redirect_url['redirect_url'])) ;
	           		 $clientEndpoint->save() ;
	            
	           		 return Redirect::route('home')
	              		  ->with('success', '客户端已注册。请记住客户端认证码（client_secret）：'.$c->secret);
         		   }
       		 }

        return Redirect::route('clients.create')
            ->withInput()
            ->withErrors($c->errors());
	}

	public function destroy($id)//删除已注册客户端
	{
		// Need Auth
        $c = Client::find($id);
        $c ->delete();
        return Redirect::route('clients.index');
	}
}
