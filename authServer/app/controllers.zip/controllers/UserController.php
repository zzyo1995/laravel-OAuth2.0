<?php

use Illuminate\Support\Facades\Input;
class UserController extends BaseController {

    public function __construct()
    {
        $this->beforeFilter('auth', array('only' => array('edit','show')));//在访问edit、show之前必须经过auth过滤器
        $this->beforeFilter('user.admin', array('only' => 'index'));
    }

    public function index()
    {
        $deleteButton = 'hide';//隐藏删除按钮
        if (Auth::check()) {
            $privileges = Auth::user()->group->getPrivileges();
            if (in_array('users', $privileges))//如果当前用户是管理员，则使能删除按钮
                $deleteButton = 'show';
        }

        $allUsers = User::all();//提取用户信息
        $activeUserRecs = ActiveUser::all();//提取在线用户信息
        $activeUsers = array();
        $clientActiveUsers = User::getClientActiveUsers() ;// 获取客户端在线用户信息
        
        foreach ($activeUserRecs as $auc) {
            $activeUsers[] = $auc->user;
        }
        return View::make('users.index', array('nav_active' => 'users', 'all' => $allUsers, 'active' => $activeUsers,'clientActiveUsers' => $clientActiveUsers, 'delete' => $deleteButton));//转向用户管理页面
    }
    
	public function create()
	{
		return View::make('users.create');//转至用户注册页面
	}

	public function store()
	{
		$userinfo = Input::all();//取得输入的信息
		$userinfo['group_id'] = 1;
		$u = new User($userinfo);//注册新用户

		if($u->save()) {
		//save方法定义在vendor/laravelbook/ardent/src/LaravelBook/Ardent/Ardent.php
			return Redirect::route('users.show', $u->id) //如果保存成功，重定向到users.show
				->with('success', '用户已注册。');
		}//route方法定义在/vendor/laravel/framework/src/Illuminate/Routing/Redirector.php中

    		return Redirect::route('users.create')//重新加载用户注册页面
    			->withInput()
    			->withErrors($u->errors());
	}

	public function show($id)//查看用户信息
	{
        $user = User::find($id);
        $com = is_numeric($id) ;
        //判断输入是否正确，输入必须是数字
        if ($user == null || $com == false)
            App::abort(415);
        $currentId = Auth::check()? Auth::user()->id : -1;
        
        //添加用来判断只有管理员才能访问其余用户信息
		$currentUser = User::find($currentId) ;
		$group = $currentUser->group ;
	
		if(strstr($group->privileges,"users") === false)
		{
			//用户是非管理员，没有查看其他用户的权限
			$currentUser->deleteExpiredTokens();
			$sessions = $currentUser->getSessions();
			return View::make('users.show', array('user' => $currentUser, 'currId' => $currentId, 'sessions' => $sessions,'error'=>'没有权限查看其余用户信息')) ;
		}
		
		$user->deleteExpiredTokens();
		$sessions = $user->getSessions();
		return View::make('users.show', array('user' => $user, 'currId' => $currentId, 'sessions' => $sessions)) ;
	}

	public function edit($id)
	{
        // 已使用filter保证用户已登录
        if (Auth::user()->id != $id)
            return Redirect::route('users.show', $id);

        $user = User::find($id);
		return View::make('users.edit', array('user' => $user));
	}

	public function update($id)
	{
		$user = User::find($id);
        if (Input::get('mode') == 'update-profile') {
            // 修改个人信息
            $user->name = Input::get('name');
            $user->password_confirmation = $user->password;
            if(Input::has('phone'))
            	$user->phone = Input::get('phone') ;
            if(Input::has('sex'))
            	$user->sex = Input::get('sex') ;
            if(Input::has('address'))
            	$user->address = Input::get('address') ;
        } else {
            // 修改密码
            $credentials = array('email' => $user->email, 'password' => Input::get('oldpassword'));
            if (Auth::validate($credentials)) {
                $user->password = Input::get('password');
                $user->password_confirmation = Input::get('password_confirmation');
            } else {    // 旧密码错误
                return Response::json(array('result'=>'failed','error_msg'=>'1密码错误')) ;
            }
        }
		if ($user->updateUniques()) {
			return Response::json(array('result'=>'success','error_msg'=>'2用户信息已更新成功！')) ;
		}

        //$e = $user->errors();
		return Response::json(array('result'=>'failed','error_msg'=>'3用户信息已更新失败！')) ;
	}

	public function destroy($id)//删除用户
	{
		// Need Auth
        $user = User::find($id);
        $user->delete();
        return Redirect::route('users.index');
	}

	public function revokeToken($id)
	{
		$session_id = Input::get('session_id');
		$session = DB::table('oauth_sessions')
			->where('id', $session_id)
			->first();
		if ($session->owner_type == 'user' && $session->owner_id == $id) {
			DB::table('oauth_sessions')
				->where('id', $session_id)
				->delete();
		}
		return Redirect::route('users.show', $id);
	}

    public function newPassword($id)
    {
        $user = User::find($id);
        return View::make('password.new', array('user' => $user));
    }

    /**
     * web端更新用户头像
     */
    public function saveFaceImage()
    {
    	
    	$input = Input::all() ;
    	
    	//最后的图片应该显示像素值
    	$img_w = 300 ;
    	$img_h = 300 ;
    	$img_quality = 90 ;
    	$filepath = base_path()."/public".$input['path'] ;

    	//取出图片的实际大小
    	list($width,$height,$type,$attr)  = getimagesize($filepath);
    	
    	
    	//计算截取的图片的实际大小
    	$realWidth = round($input['w']*$width/300,0) ;
    	$realHeight = round($input['h']*$height/400,0) ;
    	
    	//计算出截取的图片的起始坐标
    	$x_len = round($input['x']*$width/300,0) ;
    	$y_len = round($input['y']*$height/400,0) ;

    	//生成临时文件，用户存放图片内容
    	$tmpfilename = tempnam(base_path().'/public/img', Auth::user()->id) ;
    	
    	switch ($type)
    	{
    		case 2 :
    			//jpg
    			$img_r = imagecreatefromjpeg($filepath) ;
    			$dst_r = imagecreatetruecolor($img_w, $img_h) ;
    			imagecopyresampled($dst_r, $img_r, 0, 0, $x_len, $y_len,$img_w,$img_h, $realWidth, $realHeight) ;
    			imagejpeg($dst_r,$tmpfilename,$img_quality) ;
    			imagedestroy($img_r) ;
    			imagedestroy($dst_r) ;
	    		break;
    		case 3:
    			//png
    			$img_r = imagecreatefrompng($filepath) ;
    			imagepng($img_r,$tmpfilename) ;
    			$dst_r = imagecreatetruecolor($img_w, $img_h) ;
    			imagesavealpha($img_r, true) ;
    			imagealphablending($dst_r, false) ;
    			imagesavealpha($dst_r, true) ;
    			imagecopyresampled($dst_r, $img_r, 0, 0, $x_len, $y_len,$img_w,$img_h, $realWidth, $realHeight) ;
    			imagepng($dst_r,$tmpfilename) ;
    			imagedestroy($dst_r) ;
    			imagedestroy($img_r) ;
    			break ;
    		default:
    			return Response::json(array("result"=>"failed","error_msg"=>"unsupport image type")) ;
    	}

		//修改文件权限
		chmod($tmpfilename,0755) ;

    	//对图片进行md5
	   	$md5_str = md5_file($tmpfilename) ;
	   	//对文件进行重命名
	   	rename($tmpfilename,base_path()."/public/img/".$md5_str) ;
    	
	   	$user = User::find(Auth::user()->id) ;
	   	
	   	$user->portrait = $md5_str ;
	   	
	   	//默认规则中有密码和密码确认项匹配的规则，需要设置相同
	   	$user->password_confirmation = $user->password;



	   	if($user->updateUniques())
	   	{
	   		return Response::json(array("result"=>"success")) ;
	   	}

	   	return Response::json(array("result"=>"failed","error_msg"=>$user->errors())) ;
       }
       
       /**
        * web端通过ajax上传文件
        */
       public function userImageUploadFromWeb()
       {
	       	//获取上传的文件
	       	$file = Input::file('filename') ;

	       	if($file == NULL)
	       	{
	       		return Response::Json(array('result'=>'failed','error_msg'=>'上传图片失败，未选择图片！')); ;
	       	}
	       	if(!$file->isValid())
	       	{
	       		return Response::Json(array('result'=>'failed','error_msg'=>'上传图片失败，非法图片！'));
	       	}       
	       	
	       	$userid = Auth::user()->id ;
	       	$user = User::find($userid) ;
	       	$file->move(base_path().'/public/img/',$user->username) ;
	       	
	       	list($width,$height,$type,$attr)  = getimagesize(base_path().'/public/img/'.$user->username);
	       	
	       	//判断文件是否是支持的图片格式
	       	if(getimagesize(base_path().'/public/img/'.$user->username) == false)
	       	{
	       		return Response::json(array("result"=>"failed","error_msg"=>"上传图片失败，上传了不支持的文件格式！")) ;
	       	}
	       	
	       	$ret = array("result"=>"success","filepath"=>"/img/".$user->username,"width"=>$width,"height"=>$height) ;
	       	return	Response::json($ret);
       }
}
