<?php

class AdminController extends BaseController {

    public function __construct()
    {
        $this->beforeFilter('user.admin');
    }

	public function home()
	{
        	return View::make('admin.home', array('nav_active' => "home"));//转向admin的管理页面
	}

	public function users()
	{
       	 	return View::make('users.index', array('nav_active' => "users"));
	}
}
